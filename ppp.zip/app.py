from flask import Flask, render_template, request, redirect, flash, session
from werkzeug.utils import secure_filename

import mysql
import os

app=Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = 'static/upload/'

conn = mysql.connector.connect(host="localhost", user="root", password="", database="ome")
cursor = conn.cursor()


@app.route('/')
def hello():
    return render_template('home.html')
@app.route('/login')
def login():
    if 'user_id' in session:
        return redirect('/home')
    elif 'password' in session:
        return redirect('/home')
    else:
        return render_template('login.html')


def ender_template( ):
    return ender_template('registration.html')


@app.route('/registration',methods = ['POST','GET'])
def register():
    if request.method == 'POST':
        afirstname = request.form['afirstname'] 
        alastname = request.form.get('alastname')
        # add other 
        # save to database using mysql connection mention table 


    return render_template('registration.html')


@app.route('/home')
def home():
    if 'user_id' in session:
        return render_template('home.html')
    else:
        return redirect('/')

if __name__=="__main__":
    app.run(debug=True)